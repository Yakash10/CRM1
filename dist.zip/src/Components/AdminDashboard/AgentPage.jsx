import { useState } from "react";

const BrokersAndClients = () => {
  const [activeTab, setActiveTab] = useState("brokers");
  const [showModal, setShowModal] = useState(false);
  const [formData, setFormData] = useState({});
  const [editIndex, setEditIndex] = useState(null);

  const [brokers, setBrokers] = useState([
    {
      name: "Rohit Sharma",
      agency: "Skyline Realty",
      phone: "+91-9876543210",
      assigned: 10,
      deals: 4,
    },
    {
      name: "Anita Mehra",
      agency: "Elite Homes",
      phone: "+91-9123456789",
      assigned: 8,
      deals: 6,
    },
  ]);

  const [clients, setClients] = useState([
    {
      name: "Mr. Rajeev Kumar",
      owned: 3,
      email: "rajeev.kumar@example.com",
      phone: "+91-9001122334",
      status: "Paid",
    },
    {
      name: "Ms. Priya Nair",
      owned: 2,
      email: "priya.nair@example.com",
      phone: "+91-9988776655",
      status: "Pending",
    },
  ]);

  const handleInputChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleEdit = (index) => {
    const data = activeTab === "brokers" ? brokers[index] : clients[index];
    setFormData(data);
    setEditIndex(index);
    setShowModal(true);
  };

  const handleDelete = (index) => {
    if (activeTab === "brokers") {
      const updated = [...brokers];
      updated.splice(index, 1);
      setBrokers(updated);
    } else {
      const updated = [...clients];
      updated.splice(index, 1);
      setClients(updated);
    }
  };

  const handleSubmit = () => {
    if (activeTab === "brokers") {
      const updated = [...brokers];
      if (editIndex !== null) {
        updated[editIndex] = formData;
      } else {
        updated.push(formData);
      }
      setBrokers(updated);
    } else {
      const updated = [...clients];
      if (editIndex !== null) {
        updated[editIndex] = formData;
      } else {
        updated.push(formData);
      }
      setClients(updated);
    }

    setFormData({});
    setEditIndex(null);
    setShowModal(false);
  };

  return (
    <div className="p-6">
      {/* Tabs and Add Button */}
      <div className="flex flex-col sm:flex-row justify-between items-center mb-4 space-y-4 sm:space-y-0 sm:space-x-4">
        <div className="flex space-x-4">
          <button
            onClick={() => {
              setActiveTab("brokers");
              setEditIndex(null);
              setFormData({});
            }}
            className={`pb-2 ${
              activeTab === "brokers"
                ? "border-b-2 border-blue-600 font-semibold"
                : ""
            }`}
          >
            Brokers
          </button>
          <button
            onClick={() => {
              setActiveTab("clients");
              setEditIndex(null);
              setFormData({});
            }}
            className={`pb-2 ${
              activeTab === "clients"
                ? "border-b-2 border-blue-600 font-semibold"
                : ""
            }`}
          >
            External Clients
          </button>
        </div>
        <button
          onClick={() => {
            setFormData({});
            setEditIndex(null);
            setShowModal(true);
          }}
          className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
        >
          {activeTab === "brokers" ? "Add Broker" : "Add Client"}
        </button>
      </div>

      {/* Sliding Effect for Tabs */}
      <div className="relative overflow-hidden">
        <div
          className={`transition-transform duration-500 ease-in-out ${
            activeTab === "brokers"
              ? "transform translate-x-0"
              : "transform translate-x-full"
          }`}
        >
          {/* Brokers Table */}
          {activeTab === "brokers" && (
            <div className="overflow-x-auto">
              <table className="min-w-full text-sm border border-gray-300">
                <thead className="bg-gray-100">
                  <tr>
                    <th className="p-2 border">Name</th>
                    <th className="p-2 border">Agency</th>
                    <th className="p-2 border">Phone</th>
                    <th className="p-2 border">Assigned</th>
                    <th className="p-2 border">Deals</th>
                    <th className="p-2 border">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {brokers.map((b, idx) => (
                    <tr key={idx}>
                      <td className="p-2 border">{b.name}</td>
                      <td className="p-2 border">{b.agency}</td>
                      <td className="p-2 border">{b.phone}</td>
                      <td className="p-2 border">{b.assigned}</td>
                      <td className="p-2 border">{b.deals}</td>
                      <td className="p-2 border space-x-2">
                        <button
                          onClick={() => handleEdit(idx)}
                          className="text-blue-600 hover:underline"
                        >
                          Edit
                        </button>
                        <button
                          onClick={() => handleDelete(idx)}
                          className="text-red-600 hover:underline"
                        >
                          Delete
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        <div
          className={`transition-transform duration-500 ease-in-out ${
            activeTab === "clients"
              ? "transform translate-x-0"
              : "transform -translate-x-full"
          }`}
        >
          {/* Clients Table */}
          {activeTab === "clients" && (
            <div className="overflow-x-auto">
              <table className="min-w-full text-sm border border-gray-300">
                <thead className="bg-gray-100">
                  <tr>
                    <th className="p-2 border">Name</th>
                    <th className="p-2 border">Owned</th>
                    <th className="p-2 border">Email</th>
                    <th className="p-2 border">Phone</th>
                    <th className="p-2 border">Status</th>
                    <th className="p-2 border">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {clients.map((c, idx) => (
                    <tr key={idx}>
                      <td className="p-2 border">{c.name}</td>
                      <td className="p-2 border">{c.owned}</td>
                      <td className="p-2 border">{c.email}</td>
                      <td className="p-2 border">{c.phone}</td>
                      <td className="p-2 border text-green-600">{c.status}</td>
                      <td className="p-2 border space-x-2">
                        <button
                          onClick={() => handleEdit(idx)}
                          className="text-blue-600 sm:text-center hover:underline"
                        >
                          Edit
                        </button>
                        <button
                          onClick={() => handleDelete(idx)}
                          className="text-red-600  hover:underline"
                        >
                          Delete
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <h2 className="text-xl font-semibold mb-4">
              {editIndex !== null ? "Edit" : "Add"}{" "}
              {activeTab === "brokers" ? "Broker" : "Client"}
            </h2>

            {activeTab === "brokers" ? (
              <>
                <input
                  type="text"
                  name="name"
                  placeholder="Name"
                  value={formData.name || ""}
                  onChange={handleInputChange}
                  className="w-full p-2 mb-2 border rounded"
                />
                <input
                  type="text"
                  name="agency"
                  placeholder="Agency"
                  value={formData.agency || ""}
                  onChange={handleInputChange}
                  className="w-full p-2 mb-2 border rounded"
                />
                <input
                  type="text"
                  name="phone"
                  placeholder="Phone"
                  value={formData.phone || ""}
                  onChange={handleInputChange}
                  className="w-full p-2 mb-2 border rounded"
                />
                <input
                  type="number"
                  name="assigned"
                  placeholder="Assigned"
                  value={formData.assigned || ""}
                  onChange={handleInputChange}
                  className="w-full p-2 mb-2 border rounded"
                />
                <input
                  type="number"
                  name="deals"
                  placeholder="Deals"
                  value={formData.deals || ""}
                  onChange={handleInputChange}
                  className="w-full p-2 mb-2 border rounded"
                />
              </>
            ) : (
              <>
                <input
                  type="text"
                  name="name"
                  placeholder="Name"
                  value={formData.name || ""}
                  onChange={handleInputChange}
                  className="w-full p-2 mb-2 border rounded"
                />
                <input
                  type="number"
                  name="owned"
                  placeholder="Owned"
                  value={formData.owned || ""}
                  onChange={handleInputChange}
                  className="w-full p-2 mb-2 border rounded"
                />
                <input
                  type="email"
                  name="email"
                  placeholder="Email"
                  value={formData.email || ""}
                  onChange={handleInputChange}
                  className="w-full p-2 mb-2 border rounded"
                />
                <input
                  type="text"
                  name="phone"
                  placeholder="Phone"
                  value={formData.phone || ""}
                  onChange={handleInputChange}
                  className="w-full p-2 mb-2 border rounded"
                />
                <select
                  name="status"
                  value={formData.status || ""}
                  onChange={handleInputChange}
                  className="w-full p-2 mb-2 border rounded"
                >
                  <option value="Paid">Paid</option>
                  <option value="Pending">Pending</option>
                </select>
              </>
            )}

            <div className="flex justify-end space-x-2">
              <button
                onClick={() => setShowModal(false)}
                className="px-4 py-2 bg-gray-300 rounded hover:bg-gray-400"
              >
                Cancel
              </button>
              <button
                onClick={handleSubmit}
                className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
              >
                Submit
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default BrokersAndClients;
