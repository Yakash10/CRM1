import { useState } from "react";

const LeadsPage = () => {
  const [leads, setLeads] = useState([
    {
      name: "John Doe",
      contact: "john@example.com",
      property: "Skyline Tower",
      source: "Website",
      status: "New",
    },
    {
      name: "Jane Smith",
      contact: "jane@example.com",
      property: "Green Villa",
      source: "Agent",
      status: "Contacted",
    },
  ]);

  const [form, setForm] = useState({});
  const [statusFilter, setStatusFilter] = useState("");
  const [propertyFilter, setPropertyFilter] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [editIndex, setEditIndex] = useState(null);

  const handleInputChange = (e) =>
    setForm({ ...form, [e.target.name]: e.target.value });

  const handleAddLead = () => {
    if (form.name && form.contact && form.property) {
      const newLeads = [...leads];
      if (editIndex !== null) {
        newLeads[editIndex] = form;
      } else {
        newLeads.push({ ...form, status: "New" });
      }
      setLeads(newLeads);
      setForm({});
      setEditIndex(null);
      setShowForm(false);
    }
  };

  const handleEdit = (index) => {
    setForm(leads[index]);
    setEditIndex(index);
    setShowForm(true);
  };

  const handleDelete = (index) => {
    const updatedLeads = [...leads];
    updatedLeads.splice(index, 1);
    setLeads(updatedLeads);
  };

  const filteredLeads = leads.filter((lead) => {
    return (
      (statusFilter ? lead.status === statusFilter : true) &&
      (propertyFilter
        ? lead.property.toLowerCase().includes(propertyFilter.toLowerCase())
        : true)
    );
  });

  return (
    <>
      <h1 className="ms-6 text-2xl font-semibold">Leads</h1>
      <div className="p-6 space-y-6">
        {/* Filter Section */}
        <div className="flex flex-col md:flex-row md:justify-between md:items-center mb-6 gap-4">
          <div className="flex flex-col sm:flex-row sm:items-center gap-4 w-full md:w-auto">
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="border p-2 rounded w-full "
            >
              <option value="">Filter by Status</option>
              <option value="New">New</option>
              <option value="Contacted">Contacted</option>
              <option value="Follow-up">Follow-up</option>
              <option value="Converted">Converted</option>
            </select>

            <input
              type="text"
              placeholder="Filter by Property"
              value={propertyFilter}
              onChange={(e) => setPropertyFilter(e.target.value)}
              className="border p-2 rounded w-full sm:w-auto"
            />
          </div>

          {/* Add Lead Button */}
          <button
            onClick={() => {
              setForm({});
              setEditIndex(null);
              setShowForm(true);
            }}
            className="bg-blue-600 text-white px-4 py-2 rounded w-full md:w-auto"
          >
            Add Lead
          </button>
        </div>

        {/* Leads Table */}
        <div className="overflow-x-auto">
          <table className="w-full border text-sm">
            <thead className="bg-gray-100">
              <tr>
                <th className="p-2 border">Name</th>
                <th className="p-2 border">Contact Info</th>
                <th className="p-2 border">Interested Property</th>
                <th className="p-2 border">Lead Source</th>
                <th className="p-2 border">Status</th>
                <th className="p-2 border">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredLeads.map((lead, idx) => (
                <tr key={idx} className="hover:bg-gray-50">
                  <td className="p-2 border">{lead.name}</td>
                  <td className="p-2 border">{lead.contact}</td>
                  <td className="p-2 border">{lead.property}</td>
                  <td className="p-2 border">{lead.source}</td>
                  <td className="p-2 border">{lead.status}</td>
                  <td className="p-2 border flex gap-2 justify-center">
                    <button
                      onClick={() => handleEdit(idx)}
                      className="text-yellow-600 hover:text-yellow-800"
                    >
                      Edit
                    </button>
                    <button
                      onClick={() => handleDelete(idx)}
                      className="text-red-600 hover:text-red-800"
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal Popup for Form */}
      {showForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white w-[90%] max-w-[500px] rounded shadow-lg p-6 relative">
            <h2 className="text-lg font-semibold mb-4">
              {editIndex !== null ? "Edit Lead" : "Capture New Lead"}
            </h2>

            <div className="flex flex-col gap-4">
              <input
                type="text"
                name="name"
                placeholder="Full Name"
                value={form.name || ""}
                onChange={handleInputChange}
                className="border p-2 rounded"
              />
              <input
                type="text"
                name="contact"
                placeholder="Contact Info"
                value={form.contact || ""}
                onChange={handleInputChange}
                className="border p-2 rounded"
              />
              <input
                type="text"
                name="property"
                placeholder="Interested Property"
                value={form.property || ""}
                onChange={handleInputChange}
                className="border p-2 rounded"
              />
              <input
                type="text"
                name="source"
                placeholder="Lead Source"
                value={form.source || ""}
                onChange={handleInputChange}
                className="border p-2 rounded"
              />
            </div>

            <div className="mt-6 flex flex-col sm:flex-row justify-end gap-4">
              <button
                onClick={handleAddLead}
                className="bg-blue-600 text-white px-4 py-2 rounded"
              >
                {editIndex !== null ? "Update Lead" : "Add Lead"}
              </button>
              <button
                onClick={() => setShowForm(false)}
                className="px-4 py-2 border rounded text-gray-700"
              >
                Cancel
              </button>
            </div>

            {/* Close button */}
            <button
              onClick={() => setShowForm(false)}
              className="absolute top-3 right-3 text-gray-600 hover:text-gray-900 text-xl"
            >
              &times;
            </button>
          </div>
        </div>
      )}
    </>
  );
};

export default LeadsPage;
