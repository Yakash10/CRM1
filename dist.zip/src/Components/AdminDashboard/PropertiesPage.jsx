import { useState } from "react";
import { Pencil, Trash } from "lucide-react";

const PropertiesPage = () => {
  const [search, setSearch] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [editIndex, setEditIndex] = useState(null);
  const [formData, setFormData] = useState({});

  const [properties, setProperties] = useState([
    {
      name: "Skyline Tower",
      type: "Apartment",
      location: "Mumbai",
      price: "₹1.2 Cr",
      status: "Available",
    },
    {
      name: "Green Villa",
      type: "Villa",
      location: "Pune",
      price: "₹2.5 Cr",
      status: "Sold",
    },
  ]);

  // Filter properties based on search term
  const filtered = properties.filter((p) =>
    p.name.toLowerCase().includes(search.toLowerCase())
  );

  // Update formData when input changes
  const handleInputChange = (e) =>
    setFormData({ ...formData, [e.target.name]: e.target.value });

  // Save or update property
  const handleSave = () => {
    const updated = [...properties];
    if (editIndex !== null) {
      updated[editIndex] = formData; // Update existing property
    } else {
      updated.push(formData); // Add new property
    }
    setProperties(updated);
    resetForm();
  };

  // Edit existing property
  const handleEdit = (index) => {
    setFormData(properties[index]);
    setEditIndex(index);
    setShowModal(true);
  };

  // Delete a property
  const handleDelete = (index) => {
    const updated = [...properties];
    updated.splice(index, 1);
    setProperties(updated);
  };

  // Reset form data and close modal
  const resetForm = () => {
    setFormData({});
    setEditIndex(null);
    setShowModal(false);
  };

  return (
    <>
      <div className="p-6">
        <h1 className="text-2xl font-semibold text-gray-800 mb-6">
          Properties
        </h1>

        {/* Header */}
        <div className="flex flex-col sm:flex-row justify-between items-center gap-4 mb-6">
          <input
            type="text"
            placeholder="Search properties..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="border border-gray-300 p-2 rounded-lg w-full sm:w-1/2 lg:w-64 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <button
            onClick={() => {
              setShowModal(true);
              setFormData({});
              setEditIndex(null);
            }}
            className="bg-blue-600 text-white font-medium px-6 py-2 rounded-lg hover:bg-blue-700 transition-all w-full sm:w-auto"
          >
            + Add New Property
          </button>
        </div>

        {/* Table */}
        <div className="overflow-x-auto bg-white shadow-sm rounded-lg">
          <table className="w-full min-w-[700px] text-sm text-left">
            <thead className="bg-gray-100 text-gray-700 font-semibold">
              <tr>
                <th className="p-3">Name</th>
                <th className="p-3">Type</th>
                <th className="p-3">Location</th>
                <th className="p-3">Price</th>
                <th className="p-3">Status</th>
                <th className="p-3 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="text-gray-700">
              {filtered.map((p, idx) => (
                <tr
                  key={idx}
                  className="hover:bg-gray-50 transition-colors border-b"
                >
                  <td className="p-3">{p.name}</td>
                  <td className="p-3">{p.type}</td>
                  <td className="p-3">{p.location}</td>
                  <td className="p-3">{p.price}</td>
                  <td className="p-3">{p.status}</td>
                  <td className="p-3">
                    <div className="flex gap-3 justify-center">
                      <Pencil
                        onClick={() => handleEdit(idx)}
                        className="w-4 h-4 text-yellow-600 cursor-pointer hover:scale-110 transition"
                      />
                      <Trash
                        onClick={() => handleDelete(idx)}
                        className="w-4 h-4 text-red-600 cursor-pointer hover:scale-110 transition"
                      />
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Modal */}
        {showModal && (
          <div className="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50 px-4">
            <div className="bg-white p-6 rounded-xl w-full max-w-md shadow-lg animate-fadeIn">
              <h2 className="text-xl font-semibold mb-4">
                {editIndex !== null ? "Edit" : "Add"} Property
              </h2>
              <div className="space-y-3">
                <input
                  type="text"
                  name="name"
                  placeholder="Property Name"
                  value={formData.name || ""}
                  onChange={handleInputChange}
                  className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-blue-500"
                />
                <input
                  type="text"
                  name="type"
                  placeholder="Property Type"
                  value={formData.type || ""}
                  onChange={handleInputChange}
                  className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-blue-500"
                />
                <input
                  type="text"
                  name="location"
                  placeholder="Location"
                  value={formData.location || ""}
                  onChange={handleInputChange}
                  className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-blue-500"
                />
                <input
                  type="text"
                  name="price"
                  placeholder="Price"
                  value={formData.price || ""}
                  onChange={handleInputChange}
                  className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-blue-500"
                />
                <select
                  name="status"
                  value={formData.status || ""}
                  onChange={handleInputChange}
                  className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">Select Status</option>
                  <option value="Available">Available</option>
                  <option value="Sold">Sold</option>
                  <option value="Archived">Archived</option>
                </select>
              </div>

              <div className="flex justify-end mt-6">
                <button
                  onClick={resetForm}
                  className="px-4 py-2 mr-2 border rounded-lg hover:bg-gray-100"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSave}
                  className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition"
                >
                  {editIndex !== null ? "Update" : "Save"}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </>
  );
};

export default PropertiesPage;
