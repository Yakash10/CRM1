import React, { useState } from "react";

const HelpPage = () => {
  const [faqs] = useState([
    {
      question: "How do I reset my password?",
      answer: 'Go to Settings > Profile and click on "Change Password".',
    },
    {
      question: "How can I add a new property?",
      answer: 'Navigate to the Properties page and click "Add New Property".',
    },
    {
      question: "Can I export my leads?",
      answer: 'Yes, go to the Leads page and use the "Export" button.',
    },
  ]);

  const [expandedIndex, setExpandedIndex] = useState(null);
  const [form, setForm] = useState({
    name: "",
    email: "",
    message: "",
  });

  const toggleFAQ = (index) => {
    setExpandedIndex(index === expandedIndex ? null : index);
  };

  const handleFormChange = (e) => {
    const { name, value } = e.target;
    setForm({ ...form, [name]: value });
  };

  const handleFormSubmit = (e) => {
    e.preventDefault();
    alert("Ticket submitted!");
    setForm({ name: "", email: "", message: "" });
  };

  return (
    <div className="p-6 min-h-screen bg-gray-50">
      <h1 className="text-3xl font-bold mb-6">Help & Support</h1>

      {/* FAQ Section */}
      <div className="bg-white rounded shadow p-6 mb-6">
        <h2 className="text-xl font-semibold mb-4">
          Frequently Asked Questions
        </h2>
        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <div key={index}>
              <button
                onClick={() => toggleFAQ(index)}
                className="w-full text-left font-medium text-blue-600 focus:outline-none"
              >
                {faq.question}
              </button>
              {expandedIndex === index && (
                <p className="text-gray-700 mt-2">{faq.answer}</p>
              )}
              <hr className="my-2" />
            </div>
          ))}
        </div>
      </div>

      {/* Contact Support */}
      {/* <div className="bg-white rounded shadow p-6 mb-6">
        <h2 className="text-xl font-semibold mb-4">
          Submit a Ticket / Contact Support
        </h2>
        <form
          onSubmit={handleFormSubmit}
          className="grid grid-cols-1 md:grid-cols-2 gap-4"
        >
          <div>
            <label className="block font-medium mb-1">Name</label>
            <input
              type="text"
              name="name"
              value={form.name}
              onChange={handleFormChange}
              required
              className="w-full border px-3 py-2 rounded"
            />
          </div>
          <div>
            <label className="block font-medium mb-1">Email</label>
            <input
              type="email"
              name="email"
              value={form.email}
              onChange={handleFormChange}
              required
              className="w-full border px-3 py-2 rounded"
            />
          </div>
          <div className="md:col-span-2">
            <label className="block font-medium mb-1">Message</label>
            <textarea
              name="message"
              value={form.message}
              onChange={handleFormChange}
              rows="4"
              required
              className="w-full border px-3 py-2 rounded"
            ></textarea>
          </div>
          <div className="md:col-span-2 text-right">
            <button
              type="submit"
              className="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700"
            >
              Submit Ticket
            </button>
          </div>
        </form>
      </div> */}

      {/* User Guide Download */}
      {/* <div className="bg-white rounded shadow p-6 text-center">
        <h2 className="text-xl font-semibold mb-4">Need a Full Guide?</h2>
        <p className="text-gray-600 mb-4">
          Download our full CRM User Guide PDF.
        </p>
        <a
          href="/user-guide.pdf" // Replace with actual path
          download
          className="bg-green-600 text-white px-6 py-2 rounded hover:bg-green-700"
        >
          Download User Guide
        </a>
      </div> */}
    </div>
  );
};

export default HelpPage;
